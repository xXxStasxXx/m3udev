gpsCommand="navi"
streetLineKey="o"
showStreetLine=true
streetLineColor=tocolor(255,0,0)
gpsColorRed=tocolor(0,255,0)
gpsAlpha=255
DEBUG = false